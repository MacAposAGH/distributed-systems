package UDPUnicast;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;   

public class QuoteServer 
{     
	public static void main(String[] args) throws IOException 
	{         
		new QuoteServerThread().start();     
	} 
}


class QuoteServerThread extends Thread {

	protected DatagramSocket socket = null;
	protected BufferedReader in = null;
	protected boolean moreQuotes = true;

	public QuoteServerThread() throws IOException {
		this("QuoteServerThread");
	}

	public QuoteServerThread(String name) throws IOException 
	{
		super(name);
	
		socket = new DatagramSocket(4445);

		try {
			in = new BufferedReader(new FileReader("one-liners.txt"));
		} catch (FileNotFoundException e) {
			System.err.println("Could not open quote file. Serving time instead.");
		}
	}

	public void run() {

		while (moreQuotes) {
			try {
				byte[] buf = new byte[256];

				// receive request
				DatagramPacket packet = new DatagramPacket(buf, buf.length);
				socket.receive(packet);

				// figure out response
				String dString = (in == null) ? new Date().toString() : getNextQuote();
				buf = dString.getBytes();

				// send the response to the client at "address" and "port"
				InetAddress address = packet.getAddress();
				int port = packet.getPort();
				System.out.println("A packet received from: " + address.getHostAddress() + ":" + port + ", payload: " +
						new String(packet.getData(), packet.getOffset(), packet.getLength()));

				packet = new DatagramPacket(buf, buf.length, address, port);
				socket.send(packet);
				System.out.println("Packet sent to the sender");
				
			} catch (IOException e) {
				e.printStackTrace();
				//moreQuotes = false;
			}
		}
		socket.close();
	}

	protected String getNextQuote() {
		String returnValue = null;
		try {
			if ((returnValue = in.readLine()) == null) {
				in.close();
				moreQuotes = false;
				returnValue = "No more quotes. Goodbye.";
			}
		} catch (IOException e) {
			returnValue = "IOException occurred in server.";
		}
		return returnValue;
	}
}

