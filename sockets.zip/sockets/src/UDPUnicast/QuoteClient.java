package UDPUnicast;
/*
 * Copyright (c) 1995, 2008, Oracle and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Oracle or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

import java.io.*;
import java.net.*;
import java.util.*;

public class QuoteClient {
	public static void main(String[] args) throws IOException {

		InetAddress address = InetAddress.getByName("127.0.0.7");
		int port = 4445;

		// get a datagram socket
		DatagramSocket socket = new DatagramSocket();
		//DatagramSocket socket = new DatagramSocket(55555, InetAddress.getByName("127.0.0.7")); //you can specify the local port and the address as well
				
		// send a request
		byte[] buf1 = "abcdefghijklmnopqrstuvwxyz".getBytes();//new byte[256];
		DatagramPacket packet = new DatagramPacket(buf1, buf1.length, address, port);
		System.out.println("Sending a packet...");
		socket.send(packet);
		System.out.println("Sent.");

		// get response
		byte[] buf2 = new byte[256];
		packet = new DatagramPacket(buf2, buf2.length);
		System.out.println("Waiting for a response...");
		socket.receive(packet);

				
		// display response
		String received = new String(packet.getData(), packet.getOffset(), packet.getLength());
		System.out.println("Answer from the server: " + received);
				
		socket.close();
	}
}
